<?php
include("header.php");
?>



<div class="breadcumb-wrapper" data-bg-src="assets/img/bg/header-bg-1-1.jpg">
    <div class="container z-index-common">
        <div class="breadcumb-content">
            <h1 class="breadcumb-title">Team Details</h1>
            <div class="breadcumb-menu-wrap">
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li>Team Details</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<section class="space-top space-extra-bottom">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-11 wow fadeInUp text-center" data-wow-delay="0.3s">
                <img src="assets/img/soon.png" alt="">
            </div>
        </div>
    </div>
</section>



<?php
include("footer.php");
?>